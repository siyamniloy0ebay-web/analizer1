package crawler.core.Traverser;

import crawler.core.XpathEngine.SuperXpath;

import java.util.HashSet;
import java.util.Set;

public class TreeTraverser1 {

    private Set<String> leafNodes = new HashSet<String>();
    private SuperXpath superXpath;

    public TreeTraverser1(SuperXpath superXpath) {
        this.superXpath = superXpath;
    }




}
